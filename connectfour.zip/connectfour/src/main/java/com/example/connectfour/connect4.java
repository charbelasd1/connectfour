package com.example.connectfour;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class connect4 extends Application {

    private static final int COLUMNS = 7; // Number of columns in the grid
    private static final int ROWS = 6; // Number of rows in the grid
    private static final int TILE_SIZE = 90; // Base size of each tile

    private boolean redMove = true; // Flag to track if it's red's turn
    private Disc[][] grid = new Disc[COLUMNS][ROWS]; // 2D array to store discs

    private Pane discRoot = new Pane(); // Pane to hold discs
    private Label winnerLabel = new Label(); // Label to display the winner
    private Button restartButton = new Button("Restart"); // Button to restart the game
    private Label scoreLabel = new Label(); // Label to display the scores
    private Stage stage; // Stage to hold the scene

    private int redWins = 0; // Counter for red wins
    private int blackWins = 0; // Counter for black wins

    private Parent createContent() {
        Pane root = new Pane(); // Create the root pane
        root.getChildren().add(discRoot); // Add the disc root pane to the root

        Shape gridShape = makeGrid(); // Create the grid shape
        root.getChildren().add(gridShape); // Add the grid shape to the root
        root.getChildren().addAll(makeColumns()); // Add columns to the root

        // Add score label to the root
        scoreLabel.setText("Red Wins: " + redWins + " | BLACK Wins: " + blackWins);
        scoreLabel.setTranslateX(10);
        scoreLabel.setTranslateY(10);


        return root; // Return the root pane
    }

    private Shape makeGrid() { // Method to create the grid shape
        Shape shape = new Rectangle((COLUMNS + 1) * TILE_SIZE, (ROWS + 1) * TILE_SIZE); // Create a rectangle for the grid

        for (int y = 0; y < ROWS; y++) { // Loop through rows
            for (int x = 0; x < COLUMNS; x++) { // Loop through columns
                Circle circle = new Circle(TILE_SIZE / 2); // Create a circle for each tile
                circle.setCenterX(TILE_SIZE / 2); // Set the circle's center X
                circle.setCenterY(TILE_SIZE / 2); // Set the circle's center Y
                circle.setTranslateX(x * (TILE_SIZE + 5) + TILE_SIZE / 4); // Set the circle's X translation
                circle.setTranslateY(y * (TILE_SIZE + 5) + TILE_SIZE / 4); // Set the circle's Y translation

                shape = Shape.subtract(shape, circle); // Subtract the circle from the shape
            }
        }

        shape.setFill(Color.ORANGE); // Set the grid's background color to blue
        return shape; // Return the grid shape
    }

    private List<Rectangle> makeColumns() { // Method to create the columns
        List<Rectangle> list = new ArrayList<>(); // Create a list to hold rectangles

        for (int x = 0; x < COLUMNS; x++) { // Loop through columns
            Rectangle rect = new Rectangle(TILE_SIZE, (ROWS + 1) * TILE_SIZE); // Create a rectangle for each column
            rect.setTranslateX(x * (TILE_SIZE + 5) + TILE_SIZE / 4); // Set the rectangle's X translation
            rect.setFill(Color.TRANSPARENT); // Set the rectangle's fill to transparent

            rect.setOnMouseEntered(e -> rect.setFill(Color.rgb(200, 200, 50, 0.3))); // Change color on mouse enter
            rect.setOnMouseExited(e -> rect.setFill(Color .TRANSPARENT)); // Reset color on mouse exit

            final int column = x; // Capture the current column index for use in the event handler
            rect.setOnMouseClicked(e -> placeDisc(new Disc(redMove), column)); // Set action for mouse click to place a disc

            list.add(rect); // Add the rectangle to the list
        }

        return list; // Return the list of column rectangles
    }

    private boolean isMoveInProgress = false; // Flag to track if a move is in progress

    private void placeDisc(Disc disc, int column) { // Method to place a disc in the specified column
        if (isMoveInProgress) return; // Prevent further clicks if a move is in progress

        int row = ROWS - 1; // Start from the bottom row
        do {
            if (!getDisc(column, row).isPresent()) // Check if the current position is empty
                break;

            row--; // Move up if the position is occupied
        } while (row >= 0);

        if (row < 0) // If no valid row is found, return
            return;

        grid[column][row] = disc; // Place the disc in the grid
        discRoot.getChildren().add(disc); // Add the disc to the pane
        disc.setTranslateX(column * (TILE_SIZE + 5) + TILE_SIZE / 4); // Set the X position of the disc

        final int currentRow = row; // Capture the current row for later use

        isMoveInProgress = true; // Set the flag to indicate a move is in progress

        TranslateTransition animation = new TranslateTransition(Duration.seconds(0.5), disc); // Create an animation for the disc
        animation.setToY(row * (TILE_SIZE + 5) + TILE_SIZE / 4); // Set the final Y position of the disc
        animation.setOnFinished(e -> {
            isMoveInProgress = false; // Reset the flag after the animation is finished
            if (gameEnded(column, currentRow)) { // Check if the game has ended
                gameOver(); // If so, handle game over
            } else {
                redMove = !redMove; // Switch turns
            }
        });
        animation.play(); // Play the animation
    }

    private boolean gameEnded(int column, int row) { // Method to check if the game has ended
        List<Point2D> vertical = IntStream.rangeClosed(row - 3, row + 3) // Check vertical alignment
                .mapToObj(r -> new Point2D(column, r))
                .collect(Collectors.toList());

        List<Point2D> horizontal = IntStream.rangeClosed(column - 3, column + 3) // Check horizontal alignment
                .mapToObj(c -> new Point2D(c, row))
                .collect(Collectors.toList());

        Point2D topLeft = new Point2D(column - 3, row - 3); // Top-left for diagonal check
        List<Point2D> diagonal1 = IntStream.rangeClosed(0, 6)
                .mapToObj(i -> topLeft.add(i, i))
                .collect(Collectors.toList());

        Point2D botLeft = new Point2D(column - 3, row + 3); // Bottom-left for diagonal check
        List<Point2D> diagonal2 = IntStream.rangeClosed(0, 6)
                .mapToObj(i -> botLeft.add(i, -i))
                .collect(Collectors.toList());

        return checkRange(vertical) || checkRange(horizontal)
                || checkRange(diagonal1) || checkRange(diagonal2); // Check all directions for a win
    }

    private boolean checkRange(List<Point2D> points) { // Method to check for a winning range
        int chain = 0; // Counter for consecutive discs

        for (Point2D p : points) { // Loop through the points
            int column = (int) p.getX(); // Get the column index
            int row = (int) p.getY(); // Get the row index

            Disc disc = getDisc(column, row).orElse(new Disc(!redMove)); // Get the disc or create a placeholder
            if (disc.red == redMove) { // Check if the disc matches the current player's color
                chain++; // Increment the chain counter
                if (chain == 4) { // If four in a row, return true
                    return true;
                }
            } else {
                chain = 0; // Reset the chain counter if the color doesn't match
            }
        }

        return false; // No winning condition met
    }

    private void gameOver() { // Method to handle game over
        String winner = redMove ? "RED" : "BLACK"; // Determine the winner
        winnerLabel.setText("Winner: " + winner); // Set the winner label

        // Update the win counters
        if (redMove) {
            redWins++; // Increment red wins
        } else {
            blackWins++; // Increment black wins
        }
        scoreLabel.setText("Red Wins: " + redWins + " | BLACK Wins: " + blackWins); // Update the score display

        showGameOverScene(); // Show the game over scene
    }

    private void showGameOverScene() { // Method to display the game over scene
        VBox gameOverLayout = new VBox(30); // Create a vertical box layout
        gameOverLayout.setAlignment(Pos.CENTER); // Center the elements

        // Customize winner label
        winnerLabel.setTextFill(Color.ORANGE);
        winnerLabel.setStyle("-fx-font-size: 48px; -fx-font-weight: bold; -fx-background-color: BLACK; " +
                "-fx-padding: 20; -fx-border-radius: 10; -fx-background-radius: 10; -fx-border-color: WHITE; " +
                "-fx-border-width: 2;"); // Add background, padding, and border

        // Customize restart button
        restartButton.setStyle("-fx-background-color:BLACK;-fx-font-size: 30px; -fx-base: #ffcc00; -fx-text-fill: ORANGE; " +
                "-fx-padding: 15; -fx-background-radius: 20; -fx-border-radius: 20; " +
                "-fx-border-color: black; -fx-border-width: 2;"); // Add padding and border
        restartButton.setMinSize(200, 60); // Set minimum size for the button
        restartButton.setOnAction(e -> restartGame());

        // Create a label for displaying the win counters
        Label winCounterLabel = new Label("Red Wins: " + redWins + " | BLACK Wins: " + blackWins);
        winCounterLabel.setStyle("-fx-font-size: 40px; -fx-text-fill: ORANGE;-fx-background-color: BLACK; -fx-padding: 20; -fx-padding: 15; -fx-background-radius: 20; -fx-border-radius: 20;-fx-border-color: black; -fx-border-width: 2;"); // Style the win counter

        gameOverLayout.getChildren().addAll(winnerLabel, restartButton, winCounterLabel); // Add elements to the layout

        Scene gameOverScene = new Scene(gameOverLayout, 600, 400); // Increased size for the scene
        stage.setScene(gameOverScene); // Set the game over scene
    }

    private void restartGame() { // Method to restart the game
        discRoot.getChildren().clear(); // Clear the discs from the pane
        grid = new Disc[COLUMNS][ROWS]; // Reset the grid
        redMove = true; // Reset the turn to red
        winnerLabel.setText(""); // Clear the winner label
        stage.setScene(new Scene(createContent(), (COLUMNS + 1) * TILE_SIZE, (ROWS + 1) * TILE_SIZE)); // Return to game scene
    }

    private Optional<Disc> getDisc(int column, int row) { // Method to get a disc at a specific position
        if (column < 0 || column >= COLUMNS || row < 0 || row >= ROWS)
            return Optional.empty(); // Return empty if out of bounds

        return Optional.ofNullable(grid[column][row]); // Return the disc if present
    }

    private static class Disc extends Circle { // Class to represent a disc
        private final boolean red; // Flag to determine the color of the disc

        public Disc(boolean red) { // Constructor
            super(TILE_SIZE / 2, red ? Color.RED : Color.BLACK); // Set the color based on the player's turn
            this.red = red;

            setCenterX(TILE_SIZE / 2); // Set the center X
            setCenterY(TILE_SIZE / 2); // Set the center Y
        }
    }

    @Override
    public void start(Stage stage) throws Exception { // Method to start the application
        this.stage = stage;
        stage.setScene(new Scene(createContent(), (COLUMNS + 1) * TILE_SIZE, (ROWS + 1) * TILE_SIZE)); // Set the initial scene
        stage.setResizable(true); // Allow the stage to be resizable
        stage.widthProperty().addListener((obs, oldVal, newVal) -> resizeComponents()); // Listen for width changes
        stage.heightProperty().addListener((obs, oldVal, newVal) -> resizeComponents()); // Listen for height changes
        stage.show(); // Show the stage
    }

    private void resizeComponents() { // Method to resize components based on the stage size
        double width = stage.getWidth(); // Get the current width
        double height = stage.getHeight(); // Get the current height
        double tileSize = Math.min(width / (COLUMNS + 1), height / (ROWS + 1)); // Calculate the tile size based on the smaller dimension

        // Update the size of the grid and discs
        for (int x = 0; x < COLUMNS; x++) {
            for (int y = 0; y < ROWS; y++) {
                Disc disc = grid[x][y];
                if (disc != null) {
                    disc.setRadius(tileSize / 2); // Update the radius of existing discs
                    disc.setCenterX(tileSize / 2);
                    disc.setCenterY(tileSize / 2);
                    disc.setTranslateX(x * (tileSize + 5) + tileSize / 4);
                    disc.setTranslateY(y * (tileSize + 5) + tileSize / 4);
                }
            }
        }
    }

    public static void main(String[] args) { // Main method to launch the application
        launch(args);
    }
}